package com.example.BackendDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.BackendDemo.model.Animal;
import com.example.BackendDemo.services.AnimalService;

@RestController
@RequestMapping("/api/Animal")
public class AnimalController {

    @GetMapping("/")
    public String home() {
        return "La API está activa. Puedes acceder a /api/Animal para gestionar los animales.";
    }

    @Autowired
    private AnimalService animalService;

    @GetMapping
    public List<Animal> getAllAnimals() {
        return animalService.getAllAnimals();
    }

    @PostMapping
    public Animal saveAnimal(@RequestBody Animal nuevoAnimal) {
        return animalService.createAnimal(nuevoAnimal);
    }

    @GetMapping("/{id}")
    public Animal getAnimalById(@PathVariable Long id) {
        return animalService.getAnimalById(id)
            .orElseThrow(() -> new RuntimeException("Animal no encontrado"));
    }

    @PutMapping("/{id}")
    public Animal updateAnimal(@PathVariable Long id, @RequestBody Animal animalDetails) {
        return animalService.updateAnimal(id, animalDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteAnimal(@PathVariable Long id) {
        animalService.deleteAnimal(id);
    }
}
