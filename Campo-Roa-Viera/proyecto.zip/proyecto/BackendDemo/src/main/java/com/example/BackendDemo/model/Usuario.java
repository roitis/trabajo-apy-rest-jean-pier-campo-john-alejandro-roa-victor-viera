package com.example.BackendDemo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "document")
    private String document; // Cambiado a String (con mayúscula)

    @Column(name = "usuario")
    private String name; // Cambiado a String (con mayúscula)

    @Column(name = "email")
    private String email; // Cambiado a String (con mayúscula)

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocument() { // Cambiado a String (con mayúscula)
        return document;
    }

    public void setDocument(String document) { // Agregado el setter
        this.document = document;
    }

    public String getName() { // Agregado el getter
        return name;
    }

    public void setName(String name) { // Agregado el setter
        this.name = name;
    }

    public String getEmail() { // Agregado el getter
        return email;
    }

    public void setEmail(String email) { // Agregado el setter
        this.email = email;
    }
}
