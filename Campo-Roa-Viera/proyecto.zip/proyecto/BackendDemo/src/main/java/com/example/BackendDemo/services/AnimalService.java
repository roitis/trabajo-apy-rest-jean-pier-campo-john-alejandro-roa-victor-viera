package com.example.BackendDemo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BackendDemo.model.Animal;
import com.example.BackendDemo.repository.AnimalRepository;

@Service
public class AnimalService {

    @Autowired
    private AnimalRepository animalRepository;

    public List<Animal> getAllAnimals() {
        return animalRepository.findAll();
    }

    public Animal createAnimal(Animal newAnimal) {
        return animalRepository.save(newAnimal);
    }

    public Optional<Animal> getAnimalById(Long id) {
        return animalRepository.findById(id);
    }

    public Animal updateAnimal(Long id, Animal animalDetails) {
        return animalRepository.findById(id).map(animal -> {
            animal.setNombre(animalDetails.getNombre());
            animal.setEspecie(animalDetails.getEspecie());
            animal.setEdad(animalDetails.getEdad());
            animal.setFecha_Ingreso(animalDetails.getFecha_Ingreso());
            animal.setEstado(animalDetails.getEstado());
            return animalRepository.save(animal);
        }).orElseThrow(() -> new RuntimeException("Animal no encontrado"));
    }

    public void deleteAnimal(Long id) {
        animalRepository.deleteById(id);
    }
}
